// popup.js — v3 with tags and settings

const State = {
  mode: 'work',
  spreadsheetId: null,
  tasks: [],
  hints: [],
  tags: [],
  selectedTagsForCapture: [],
  newTagColor: '#ff4208',
  taskFilter: 'all',
  capSN: 'signal',
  capCtxOpen: false,
  taskRowMap: {},
  ritualPhase: null,
};

const TAG_PALETTE = ['#ff4208','#4827af','#22c55e','#f59e0b','#3b8bd4','#ef4444','#7e60dc','#ff693b','#0f6e56','#be185d','#0891b2','#65a30d'];

const storage = {
  get: (keys) => new Promise(res => chrome.storage.local.get(keys, res)),
  set: (obj)  => new Promise(res => chrome.storage.local.set(obj, res)),
};

// ── INIT ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const data = await storage.get(['spreadsheetId','onboardingDone','mode']);
  if (!data.onboardingDone || !data.spreadsheetId) {
    showView('onboarding'); initOnboarding();
  } else {
    State.spreadsheetId = data.spreadsheetId;
    State.mode = data.mode || 'work';
    showView('app');
    applyMode(State.mode);
    await loadTagsFromSheet();
    initApp();
  }
});

// ── VIEWS ──────────────────────────────────────────────
function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`view-${id}`).classList.add('active');
}

function showPane(id) {
  document.querySelectorAll('.pane').forEach(p => p.style.display = 'none');
  const pane = document.getElementById(`pane-${id}`);
  if (pane) pane.style.display = 'flex';
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.pane === id));
  if (id === 'tasks')    loadTasks();
  if (id === 'ritual')   loadRitual();
  if (id === 'review')   loadReview();
  if (id === 'settings') loadSettings();
}

// ── MODE ───────────────────────────────────────────────
function applyMode(mode) {
  State.mode = mode;
  const shell = document.getElementById('app-shell');
  shell.classList.toggle('personal', mode === 'personal');
  shell.classList.toggle('work', mode === 'work');
  document.getElementById('ctx-label').textContent = mode;
  storage.set({ mode });
  loadFooterStats();
}

document.getElementById('mode-toggle-track').addEventListener('click', () => {
  applyMode(State.mode === 'work' ? 'personal' : 'work');
  loadTasks();
});

// ── ONBOARDING ─────────────────────────────────────────
let obStep = 0;
function initOnboarding() {
  document.getElementById('ob-start-btn').addEventListener('click', () => obGoTo(1));
  document.getElementById('ob-connect-btn').addEventListener('click', connectGoogle);
  document.getElementById('ob-done-btn').addEventListener('click', finishOnboarding);
  document.querySelectorAll('.ob-cta').forEach(b => {
    b.style.cssText = 'width:100%;padding:11px;border-radius:10px;border:none;font-family:"DM Sans",sans-serif;font-size:12px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;background:linear-gradient(135deg,#ff4208 0%,#4827af 100%);color:#fff;margin-top:auto;transition:opacity .2s';
  });
}

function obGoTo(step) {
  document.getElementById(`ob-p${obStep}`).classList.remove('active');
  obStep = step;
  document.getElementById(`ob-p${step}`).classList.add('active');
  [0,1,2].forEach(i => {
    const d = document.getElementById(`dot${i}`);
    d.className = i < step ? 'ob-dot done' : i === step ? 'ob-dot active' : 'ob-dot next';
  });
}

async function connectGoogle() {
  const btn = document.getElementById('ob-connect-btn');
  btn.textContent = 'Connecting…'; btn.disabled = true;
  let errEl = document.getElementById('ob-error');
  try {
    const token = await new Promise((res, rej) => {
      chrome.runtime.sendMessage({ type: 'GET_AUTH_TOKEN' }, r => {
        if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message));
        else if (!r) rej(new Error('No response from background'));
        else if (r.error) rej(new Error(r.error));
        else res(r.token);
      });
    });
    document.getElementById('ob-gstatus').textContent = 'connected';
    document.getElementById('ob-gstatus').className = 'ob-status done';
    [0,1,2,3].forEach(i => document.getElementById(`perm${i}`).classList.add('ok'));
    btn.textContent = 'Creating your sheet…';
    const id = await createSpreadsheet();
    State.spreadsheetId = id;
    await storage.set({ spreadsheetId: id, onboardingDone: true });
    obGoTo(2);
  } catch (err) {
    btn.textContent = 'Connect with Google'; btn.disabled = false;
    if (!errEl) {
      errEl = document.createElement('div'); errEl.id = 'ob-error';
      errEl.style.cssText = 'background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:8px;padding:10px 12px;font-size:11px;color:#ef4444;line-height:1.5;margin-top:8px';
      btn.parentNode.insertBefore(errEl, btn.nextSibling);
    }
    errEl.textContent = '⚠ ' + err.message; errEl.style.display = 'block';
  }
}

function finishOnboarding() { showView('app'); applyMode('work'); initApp(); }

// ── APP INIT ───────────────────────────────────────────
function initApp() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => showPane(btn.dataset.pane));
  });
  showPane('capture');
  initCapture();
  initTaskView();
  initRitual();
  initReview();
  initSettings();
  loadFooterStats();
}

// ── TAGS ───────────────────────────────────────────────
async function loadTagsFromSheet() {
  try {
    State.tags = await readTags(State.spreadsheetId);
  } catch(_) {
    State.tags = DEFAULT_TAGS.map((name, i) => ({ name, color: TAG_PALETTE[i % TAG_PALETTE.length] }));
  }
}

function renderTagChips(containerId, selectedTags, onToggle) {
  const wrap = document.getElementById(containerId);
  if (!wrap) return;
  wrap.innerHTML = '';
  State.tags.forEach(tag => {
    const chip = document.createElement('div');
    chip.className = 'tag-chip' + (selectedTags.includes(tag.name) ? ' selected' : '');
    chip.textContent = tag.name;
    chip.style.cssText = `background:${tag.color}22;color:${tag.color};border-color:${tag.color}55`;
    chip.addEventListener('click', () => {
      onToggle(tag.name);
      renderTagChips(containerId, selectedTags, onToggle);
    });
    wrap.appendChild(chip);
  });
}

function makeTaskTagHtml(tags) {
  if (!tags || tags.length === 0) return '';
  return tags.map(tagName => {
    const tag = State.tags.find(t => t.name === tagName);
    const color = tag ? tag.color : '#888';
    return `<span class="task-tag-chip" style="background:${color}22;color:${color};border-color:${color}44">${escHtml(tagName)}</span>`;
  }).join('');
}

// ── CAPTURE ─────────────────────────────────────────────
function initCapture() {
  document.querySelectorAll('#cap-sn .sn-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      State.capSN = btn.dataset.val;
      document.querySelectorAll('#cap-sn .sn-btn').forEach(b => {
        b.className = 'sn-btn' + (b.dataset.val === State.capSN ? (State.capSN === 'signal' ? ' sig-on' : ' noi-on') : '');
      });
    });
  });

  document.getElementById('cap-ctx-toggle').addEventListener('click', () => {
    State.capCtxOpen = !State.capCtxOpen;
    document.getElementById('cap-ctx-area').classList.toggle('open', State.capCtxOpen);
    document.getElementById('cap-ctx-toggle').textContent = (State.capCtxOpen ? '− ' : '+ ') + 'add context';
  });

  document.getElementById('cap-submit-btn').addEventListener('click', submitCapture);
  document.getElementById('cap-text').addEventListener('keydown', e => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) submitCapture();
  });

  // Render tag chips for capture
  renderTagChips('cap-tags-wrap', State.selectedTagsForCapture, (tagName) => {
    const idx = State.selectedTagsForCapture.indexOf(tagName);
    if (idx >= 0) State.selectedTagsForCapture.splice(idx, 1);
    else State.selectedTagsForCapture.push(tagName);
  });
}

async function submitCapture() {
  const name = document.getElementById('cap-text').value.trim();
  if (!name) { document.getElementById('cap-text').focus(); return; }
  const btn = document.getElementById('cap-submit-btn');
  btn.textContent = 'Saving…'; btn.disabled = true;
  try {
    await appendTask(State.spreadsheetId, {
      task_name: name,
      category: State.mode,
      signal_or_noise: State.capSN,
      due_date: document.getElementById('cap-due-input').value || '',
      comment: document.getElementById('cap-ctx-area').value.trim(),
      tags: [...State.selectedTagsForCapture],
      source: 'manual', status: 'open',
    });
    // Reset
    document.getElementById('cap-text').value = '';
    document.getElementById('cap-ctx-area').value = '';
    document.getElementById('cap-ctx-area').classList.remove('open');
    document.getElementById('cap-ctx-toggle').textContent = '+ add context';
    document.getElementById('cap-due-input').value = '';
    State.capCtxOpen = false; State.capSN = 'signal';
    State.selectedTagsForCapture = [];
    document.querySelectorAll('#cap-sn .sn-btn').forEach(b => {
      b.className = 'sn-btn' + (b.dataset.val === 'signal' ? ' sig-on' : '');
    });
    renderTagChips('cap-tags-wrap', State.selectedTagsForCapture, (tagName) => {
      const idx = State.selectedTagsForCapture.indexOf(tagName);
      if (idx >= 0) State.selectedTagsForCapture.splice(idx, 1);
      else State.selectedTagsForCapture.push(tagName);
    });
    btn.textContent = '✓ Captured';
    setTimeout(() => { btn.textContent = 'Capture task'; btn.disabled = false; }, 1500);
    loadFooterStats();
  } catch (err) {
    btn.textContent = 'Capture task'; btn.disabled = false;
    alert('Error: ' + err.message);
  }
}

async function loadFooterStats() {
  try {
    const allTasks = await readAllTasks(State.spreadsheetId);
    State.tasks = allTasks; State.hints = evaluateHints(allTasks);
    const cat = allTasks.filter(t => t.category === State.mode);
    const open = cat.filter(t => ['open','in_progress'].includes(t.status));
    const sigs = open.filter(t => t.signal_or_noise === 'signal').length;
    const nois = open.filter(t => t.signal_or_noise === 'noise').length;
    const ratio = nois === 0 ? (sigs > 0 ? `${sigs}:0` : '—') : (sigs/nois).toFixed(1)+':1';
    document.getElementById('cap-sig-count').textContent = sigs;
    document.getElementById('cap-noi-count').textContent = nois;
    document.getElementById('cap-ratio').textContent = 'ratio ' + ratio;
  } catch(_) {}
}

// ── TASK VIEW ──────────────────────────────────────────
function initTaskView() {
  document.querySelectorAll('.tv-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      State.taskFilter = btn.dataset.filter;
      document.querySelectorAll('.tv-tab').forEach(b => b.classList.toggle('active', b === btn));
      renderTaskList();
    });
  });
  document.getElementById('tv-close-day-btn').addEventListener('click', () => showPane('ritual'));
}

async function loadTasks() {
  document.getElementById('tv-list').innerHTML = '<div class="loading-text">Loading…</div>';
  try {
    const allTasks = await readAllTasks(State.spreadsheetId);
    State.tasks = allTasks; State.hints = evaluateHints(allTasks);
    allTasks.forEach((t, i) => { State.taskRowMap[t.task_id] = i; });
    const now = new Date();
    document.getElementById('tv-title-text').textContent = `Today — ${State.mode}`;
    document.getElementById('tv-date-text').textContent =
      now.toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' }) +
      ` · week ${getWeekNumber()}`;
    renderTaskList();
    updateStatsRow();
  } catch (err) {
    document.getElementById('tv-list').innerHTML = `<div class="empty-state"><strong>Error</strong>${err.message}</div>`;
  }
}

function updateStatsRow() {
  const cat = State.tasks.filter(t => t.category === State.mode);
  const open = cat.filter(t => ['open','in_progress'].includes(t.status));
  const done = cat.filter(t => t.status === 'done');
  const sigs = open.filter(t => t.signal_or_noise === 'signal').length;
  const nois = open.filter(t => t.signal_or_noise === 'noise').length;
  const ratio = nois === 0 ? (sigs > 0 ? `${sigs}:0` : '—') : (sigs/nois).toFixed(1)+':1';
  document.getElementById('tv-sig-num').textContent = sigs;
  document.getElementById('tv-noi-num').textContent = nois;
  document.getElementById('tv-done-num').textContent = done.length;
  document.getElementById('tv-ratio-num').textContent = ratio;
  document.getElementById('tv-ratio-footer').textContent = ratio;
}

function renderTaskList() {
  const list = document.getElementById('tv-list');
  list.innerHTML = '';
  const cat = State.tasks.filter(t => t.category === State.mode && ['open','in_progress'].includes(t.status));
  const filter = State.taskFilter;
  const signals = cat.filter(t => t.signal_or_noise === 'signal' && (filter === 'all' || filter === 'signal'));
  const noise   = cat.filter(t => t.signal_or_noise === 'noise'  && (filter === 'all' || filter === 'noise'));
  const done    = State.tasks.filter(t => t.category === State.mode && t.status === 'done');

  if (cat.length === 0) {
    list.innerHTML = '<div class="empty-state"><strong>All clear</strong>No open tasks. Capture something.</div>';
  } else {
    if (signals.length > 0) {
      if (filter === 'all') { const l=el('div'); l.className='tv-section-label'; l.textContent='Signals'; list.appendChild(l); }
      signals.forEach((t,i) => list.appendChild(buildTaskItem(t, false, i, signals.length)));
    }
    if (noise.length > 0) {
      if (filter === 'all') { const l=el('div'); l.className='tv-section-label'; l.textContent='Noise'; list.appendChild(l); }
      noise.forEach((t,i) => list.appendChild(buildTaskItem(t, false, i, noise.length)));
    }
    if (done.length > 0 && filter === 'all') {
      const l=el('div'); l.className='tv-section-label'; l.textContent='Done'; list.appendChild(l);
      done.forEach(t => list.appendChild(buildTaskItem(t, true, 0, 0)));
    }
  }
  const total = done.length + cat.length;
  const pct = total === 0 ? 0 : Math.round((done.length/total)*100);
  document.getElementById('tv-prog-fill').style.width = pct + '%';
  document.getElementById('tv-prog-label').textContent = `${done.length} of ${total} done`;
}

function buildTaskItem(task, isDone, idx, total) {
  const hint = getHintForTask(task, State.hints);
  const dueDays = task.due_date ? Math.ceil((new Date(task.due_date) - new Date()) / 86400000) : null;
  const dueTag = dueDays !== null
    ? (dueDays <= 0 ? `<span class="tag due">due today</span>` : `<span class="tag muted">due ${formatDate(task.due_date)}</span>`)
    : '';

  const item = el('div');
  item.className = `task-item ${task.signal_or_noise}${isDone ? ' done' : ''}`;
  item.dataset.id = task.task_id;

  const canUp = !isDone && idx > 0;
  const canDn = !isDone && idx < total - 1;

  item.innerHTML = `
    <div class="task-main">
      <div class="task-check"><span class="check-tick">✓</span></div>
      <div class="task-body">
        <div class="task-name">${escHtml(task.task_name)}</div>
        <div class="task-tags" style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;margin-top:4px">
          <span class="tag ${task.signal_or_noise === 'signal' ? 'sig' : 'noi'}">${task.signal_or_noise}</span>
          ${dueTag}
          ${makeTaskTagHtml(task.tags)}
        </div>
        ${hint ? `<div class="task-hint">◎ ${escHtml(hint.message)}</div>` : ''}
      </div>
      <div class="task-actions">
        ${!isDone ? `<div class="reorder-btns">
          <button class="reorder-btn up-btn" ${canUp ? '' : 'disabled'}>↑</button>
          <button class="reorder-btn dn-btn" ${canDn ? '' : 'disabled'}>↓</button>
        </div>` : ''}
        <button class="edit-btn"><svg width="11" height="11" viewBox="0 0 13 13" fill="none"><path d="M9 1.5l2.5 2.5-7 7H2v-2.5l7-7z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg></button>
      </div>
    </div>
    <div class="edit-panel">
      <div class="edit-inner">
        <div><div class="edit-label">Rename task</div><input class="edit-input" type="text" value="${escHtml(task.task_name)}"></div>
        <div><div class="edit-label">Due date</div><input type="date" class="edit-input edit-due" value="${task.due_date || ''}"></div>
        <div><div class="edit-label">Categorise</div>
          <div class="edit-seg">
            <button class="edit-seg-btn ${task.signal_or_noise === 'signal' ? 'sig-on' : ''}" data-val="signal">▲ Signal</button>
            <button class="edit-seg-btn ${task.signal_or_noise === 'noise' ? 'noi-on' : ''}" data-val="noise">~ Noise</button>
          </div>
        </div>
        <div><div class="edit-label">Tags</div><div class="edit-tags-wrap tag-chips-wrap" id="edit-tags-${task.task_id}"></div></div>
        <div><div class="edit-label">Status note</div><textarea class="edit-note" rows="2" placeholder="Current status, blockers, context…">${escHtml(task.comment || '')}</textarea></div>
        <div class="btn-actions">
          <button class="btn-secondary cancel-edit-btn">Cancel</button>
          <button class="btn-sm primary save-edit-btn">Save</button>
        </div>
      </div>
    </div>
  `;

  // Check
  item.querySelector('.task-check').addEventListener('click', e => { e.stopPropagation(); toggleTaskDone(task); });

  // Edit tags
  const editTags = [...(task.tags || [])];
  setTimeout(() => {
    renderTagChips(`edit-tags-${task.task_id}`, editTags, (tagName) => {
      const idx = editTags.indexOf(tagName);
      if (idx >= 0) editTags.splice(idx, 1); else editTags.push(tagName);
    });
  }, 0);

  // Edit panel toggle
  const editBtn = item.querySelector('.edit-btn');
  const editPanel = item.querySelector('.edit-panel');
  editBtn.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = editPanel.classList.contains('open');
    document.querySelectorAll('.edit-panel.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.edit-btn.open').forEach(b => b.classList.remove('open'));
    if (!isOpen) { editPanel.classList.add('open'); editBtn.classList.add('open'); }
  });

  item.querySelectorAll('.edit-seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      item.querySelectorAll('.edit-seg-btn').forEach(b => b.className = 'edit-seg-btn');
      btn.className = `edit-seg-btn ${btn.dataset.val === 'signal' ? 'sig-on' : 'noi-on'}`;
    });
  });

  item.querySelector('.cancel-edit-btn').addEventListener('click', () => {
    editPanel.classList.remove('open'); editBtn.classList.remove('open');
  });

  item.querySelector('.save-edit-btn').addEventListener('click', async () => {
    const newName = item.querySelector('.edit-input').value.trim();
    if (!newName) return;
    task.task_name = newName;
    task.due_date = item.querySelector('.edit-due').value || '';
    task.signal_or_noise = item.querySelector('.edit-seg-btn.sig-on') ? 'signal' : 'noise';
    task.comment = item.querySelector('.edit-note').value.trim();
    task.tags = [...editTags];
    const rowIdx = State.taskRowMap[task.task_id];
    if (rowIdx !== undefined) await updateTask(State.spreadsheetId, task, rowIdx);
    editPanel.classList.remove('open'); editBtn.classList.remove('open');
    loadTasks();
  });

  // Reorder
  const upBtn = item.querySelector('.up-btn');
  const dnBtn = item.querySelector('.dn-btn');
  if (upBtn) upBtn.addEventListener('click', e => { e.stopPropagation(); reorderTask(task, -1); });
  if (dnBtn) dnBtn.addEventListener('click', e => { e.stopPropagation(); reorderTask(task, 1); });

  return item;
}

async function reorderTask(task, direction) {
  const group = State.tasks.filter(t =>
    t.category === State.mode && t.signal_or_noise === task.signal_or_noise && ['open','in_progress'].includes(t.status)
  );
  const idx = group.findIndex(t => t.task_id === task.task_id);
  const swapIdx = idx + direction;
  if (swapIdx < 0 || swapIdx >= group.length) return;
  const other = group[swapIdx];
  const rowA = State.taskRowMap[task.task_id];
  const rowB = State.taskRowMap[other.task_id];
  if (rowA === undefined || rowB === undefined) return;
  // Swap all fields
  [task, other].forEach((t, i) => {
    const partner = [other, task][i];
    ['task_name','signal_or_noise','due_date','comment','tags','category','status'].forEach(k => {
      const tmp = t[k]; t[k] = partner[k]; partner[k] = tmp;
    });
  });
  await Promise.all([updateTask(State.spreadsheetId, task, rowA), updateTask(State.spreadsheetId, other, rowB)]);
  loadTasks();
}

async function toggleTaskDone(task) {
  task.status = task.status === 'done' ? 'open' : 'done';
  const rowIdx = State.taskRowMap[task.task_id];
  if (rowIdx !== undefined) await updateTask(State.spreadsheetId, task, rowIdx);
  loadTasks();
}

// ── RITUAL ─────────────────────────────────────────────
function initRitual() {
  document.getElementById('ritual-cta-btn').addEventListener('click', onRitualCTA);
}

function setRitualPhase(phase) {
  State.ritualPhase = phase;
  document.getElementById('rpt-morning').classList.toggle('active', phase === 'morning');
  document.getElementById('rpt-evening').classList.toggle('active', phase === 'evening');
  const shell = document.getElementById('app-shell');
  shell.classList.remove('morning','evening'); shell.classList.add(phase);
  const now = new Date();
  document.getElementById('ritual-time-label').textContent =
    now.toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' }) +
    ' · ' + now.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' });
  if (phase === 'morning') {
    document.getElementById('ritual-phase-pill').textContent = 'Morning open';
    document.getElementById('ritual-title').textContent = 'Good morning.';
    document.getElementById('ritual-sub').textContent = 'Set your focus for today. Everything else can wait.';
    document.getElementById('ritual-cta-btn').textContent = 'Start the day';
    buildMorningOpen();
  } else {
    document.getElementById('ritual-phase-pill').textContent = 'Evening close';
    document.getElementById('ritual-title').textContent = 'Time to close the day.';
    document.getElementById('ritual-sub').textContent = 'Review what happened. Clear the slate for tomorrow.';
    document.getElementById('ritual-cta-btn').textContent = 'Close the day';
    buildEveningClose();
  }
}

function loadRitual() {
  const phase = State.ritualPhase || (getHour() >= 16 ? 'evening' : 'morning');
  setRitualPhase(phase);
}

async function buildMorningOpen() {
  const body = document.getElementById('ritual-body');
  body.innerHTML = '';
  const fs = el('div');
  fs.innerHTML = `
    <div class="ritual-section-label">Your one signal for today</div>
    <div class="focus-card">
      <div class="focus-pill-label">Primary focus</div>
      <input class="focus-input" id="morning-focus" placeholder="The one thing that makes today a success…" type="text">
      <div class="focus-hint-text">One signal task. Not two. One.</div>
    </div>`;
  body.appendChild(fs);
  try {
    const allTasks = await readAllTasks(State.spreadsheetId);
    State.tasks = allTasks; allTasks.forEach((t,i) => { State.taskRowMap[t.task_id] = i; });
    const carryover = allTasks.filter(t => t.category === State.mode && ['open','in_progress'].includes(t.status)).slice(0,5);
    if (carryover.length > 0) {
      const co = el('div');
      co.innerHTML = `<div class="ritual-section-label">Carried over — tap to confirm</div>`;
      const list = el('div'); list.style.cssText = 'display:flex;flex-direction:column;gap:5px';
      carryover.forEach(t => {
        const item = el('div'); item.className = `co-item ${t.signal_or_noise}`;
        item.innerHTML = `
          <div class="co-check"><span class="co-check-tick">✓</span></div>
          <div style="flex:1">
            <div class="co-name">${escHtml(t.task_name)}</div>
            <div class="co-meta">${t.signal_or_noise} · ${daysAgo(t.created_date)}d open</div>
          </div>`;
        item.addEventListener('click', () => item.classList.toggle('confirmed'));
        list.appendChild(item);
      });
      co.appendChild(list); body.appendChild(co);
    }
  } catch(_) {}
}

async function buildEveningClose() {
  const body = document.getElementById('ritual-body');
  body.innerHTML = '<div class="loading-text">Loading…</div>';
  try {
    const allTasks = await readAllTasks(State.spreadsheetId);
    State.tasks = allTasks; State.hints = evaluateHints(allTasks);
    allTasks.forEach((t,i) => { State.taskRowMap[t.task_id] = i; });
    const cat = allTasks.filter(t => t.category === State.mode);
    const done = cat.filter(t => t.status === 'done');
    const open = cat.filter(t => ['open','in_progress'].includes(t.status));
    const sd = done.filter(t => t.signal_or_noise === 'signal').length;
    const nd = done.filter(t => t.signal_or_noise === 'noise').length;
    const ratio = nd === 0 ? `${sd}:0` : (sd/nd).toFixed(1)+':1';
    body.innerHTML = '';
    const stats = el('div');
    stats.innerHTML = `
      <div class="ritual-section-label">Today at a glance</div>
      <div class="ev-stats">
        <div class="ev-stat s"><div class="ev-stat-num">${sd}</div><div class="ev-stat-label">signals closed</div></div>
        <div class="ev-stat n"><div class="ev-stat-num">${nd}</div><div class="ev-stat-label">noise closed</div></div>
        <div class="ev-stat r"><div class="ev-stat-num">${ratio}</div><div class="ev-stat-label">signal ratio</div></div>
      </div>`;
    body.appendChild(stats);
    if (sd > 0) {
      const win = el('div'); win.className = 'win-strip';
      win.innerHTML = `<div class="win-ico">◎</div><div class="win-text">${sd >= 3 ? `<strong>Strong signal day.</strong> You closed ${sd} signals today.` : `<strong>Progress made.</strong> You closed ${sd} signal task${sd > 1 ? 's' : ''} today.`}</div>`;
      body.appendChild(win);
    }
    if (open.length > 0) {
      const undone = el('div');
      undone.innerHTML = `<div class="ritual-section-label">Still open — what do we do with these?</div>`;
      const list = el('div'); list.style.cssText = 'display:flex;flex-direction:column;gap:6px'; list.id = 'evening-undone-list';
      open.forEach(t => {
        const item = el('div'); item.className = `res-item ${t.signal_or_noise}`; item.dataset.id = t.task_id;
        item.innerHTML = `
          <div class="res-top"><div class="res-name">${escHtml(t.task_name)}</div></div>
          <div class="res-bottom">
            <div class="res-tags">
              <span class="tag ${t.signal_or_noise === 'signal' ? 'sig' : 'noi'}">${t.signal_or_noise}</span>
              <span class="tag muted">${daysAgo(t.created_date)}d</span>
            </div>
            <select class="res-select" data-id="${t.task_id}">
              <option value="open">carry over</option>
              <option value="delegated">delegate</option>
              <option value="ignored">ignore</option>
            </select>
          </div>
          <div class="reason-wrap" id="rw-${t.task_id}">
            <div class="reason-inner">
              <div class="reason-label" id="rl-${t.task_id}">reason</div>
              <textarea class="reason-input" id="rt-${t.task_id}" rows="2" placeholder=""></textarea>
            </div>
          </div>`;
        const sel = item.querySelector('select');
        sel.addEventListener('change', () => handleResolution(sel, t.task_id, item));
        list.appendChild(item);
      });
      undone.appendChild(list); body.appendChild(undone);
    }
  } catch(err) { document.getElementById('ritual-body').innerHTML = `<div class="empty-state"><strong>Error</strong>${err.message}</div>`; }
}

function handleResolution(sel, taskId, item) {
  const val = sel.value;
  const wrap = document.getElementById(`rw-${taskId}`);
  const label = document.getElementById(`rl-${taskId}`);
  const ta = document.getElementById(`rt-${taskId}`);
  item.classList.remove('delegated','ignored'); sel.classList.remove('delegated','ignored'); wrap.classList.remove('open');
  if (val === 'delegated' || val === 'ignored') {
    item.classList.add(val); sel.classList.add(val); wrap.classList.add('open');
    label.textContent = val === 'delegated' ? 'Delegated — reason' : 'Ignored — reason';
    label.style.color = val === 'delegated' ? 'var(--delegated)' : 'var(--ignored)';
    ta.placeholder = val === 'delegated' ? 'To whom, and why?' : 'Why not worth your attention right now?';
    setTimeout(() => ta.focus(), 320);
  }
}

async function onRitualCTA() {
  const phase = State.ritualPhase || (getHour() >= 16 ? 'evening' : 'morning');
  if (phase === 'evening') {
    const selects = document.querySelectorAll('#evening-undone-list select');
    const updates = [];
    selects.forEach(sel => {
      const task = State.tasks.find(t => t.task_id === sel.dataset.id);
      if (!task) return;
      task.status = sel.value;
      const reason = document.getElementById(`rt-${sel.dataset.id}`)?.value.trim();
      if (reason) task.reason = reason;
      const rowIdx = State.taskRowMap[task.task_id];
      if (rowIdx !== undefined) updates.push(updateTask(State.spreadsheetId, task, rowIdx));
    });
    if (updates.length > 0) await Promise.all(updates);
  }
  showPane('tasks');
}

// ── REVIEW ─────────────────────────────────────────────
function initReview() {
  document.querySelectorAll('.fr-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.fr-tab').forEach(b => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.fr-panel').forEach(p => p.classList.toggle('active', p.id === `fr-${btn.dataset.panel}`));
    });
  });
  document.getElementById('fr-close-btn').addEventListener('click', closeWeek);
}

async function loadReview() {
  const now = new Date();
  document.getElementById('review-date-label').textContent =
    now.toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' }) +
    ` · week ${getWeekNumber()}`;
  try {
    const allTasks = await readAllTasks(State.spreadsheetId);
    State.tasks = allTasks; State.hints = evaluateHints(allTasks);
    allTasks.forEach((t,i) => { State.taskRowMap[t.task_id] = i; });

    // Calculate start of current week (Monday 00:00)
    const dow = now.getDay();
    const sow = new Date(now); sow.setDate(now.getDate() - (dow === 0 ? 6 : dow - 1)); sow.setHours(0,0,0,0);
    const sowStr = sow.toISOString().split('T')[0];

    const cat = allTasks.filter(t => t.category === State.mode);
    // Week-scoped: created or closed this week
    const weekTasks = cat.filter(t => {
      const created = t.created_date >= sowStr;
      const closed = t.closed_date && t.closed_date >= sowStr;
      return created || closed;
    });

    const sd = weekTasks.filter(t => t.signal_or_noise==='signal' && t.status==='done').length;
    const nd = weekTasks.filter(t => t.signal_or_noise==='noise'  && t.status==='done').length;
    const ign = weekTasks.filter(t => t.status==='ignored').length;
    const del = weekTasks.filter(t => t.status==='delegated').length;
    const closed = weekTasks.filter(t => ['done','delegated','ignored'].includes(t.status)).length;
    const comp = weekTasks.length === 0 ? 0 : Math.round((closed/weekTasks.length)*100);
    const openSigs = cat.filter(t => t.signal_or_noise==='signal' && ['open','in_progress'].includes(t.status)).length;
    const ratio = nd===0 ? `${sd}:0` : (sd/Math.max(nd,1)).toFixed(1)+':1';

    document.getElementById('fr-sig-closed').textContent = sd;
    document.getElementById('fr-noi-closed').textContent = nd;
    document.getElementById('fr-completion').textContent = comp + '%';
    document.getElementById('fr-ignored').textContent = ign;
    document.getElementById('fr-delegated').textContent = del;
    document.getElementById('fr-streak').textContent = computeStreak(allTasks);
    document.getElementById('fr-ratio-val').textContent = ratio;
    document.getElementById('fr-ratio-trend').textContent = openSigs > 0 ? `${openSigs} signals open` : '↑ all signals closed';

    const noiseTotal = Math.max(nd + del + ign, 1);
    setBar('nb-done', nd, noiseTotal); setBar('nb-del', del, noiseTotal);
    setBar('nb-ign', ign, noiseTotal);
    const carried = cat.filter(t => t.signal_or_noise==='noise' && t.status==='open').length;
    setBar('nb-carry', carried, Math.max(noiseTotal + carried, 1));

    buildAgingList('fr-aging-signals', cat.filter(t => t.signal_or_noise==='signal' && ['open','in_progress'].includes(t.status) && daysAgo(t.created_date) >= 5), 'signal');
    buildAgingList('fr-aging-noise', cat.filter(t => t.signal_or_noise==='noise' && ['open','in_progress'].includes(t.status) && daysAgo(t.created_date) >= 7), 'noise');
    drawWeekChart(allTasks);
    buildTagReview(weekTasks);
    buildComparison(allTasks);
  } catch(err) { console.error(err); }
}

function buildTagReview(tasks) {
  // Count tasks per tag
  const tagCounts = {};
  const tagDone = {};
  tasks.forEach(t => {
    (t.tags || []).forEach(tag => {
      tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      if (t.status === 'done') tagDone[tag] = (tagDone[tag] || 0) + 1;
    });
  });

  const maxCount = Math.max(...Object.values(tagCounts), 1);
  const chart = document.getElementById('fr-tag-chart');
  const breakdown = document.getElementById('fr-tag-breakdown');
  chart.innerHTML = ''; breakdown.innerHTML = '';

  if (Object.keys(tagCounts).length === 0) {
    chart.innerHTML = '<div class="empty-state"><strong>No tag data yet</strong>Add tags when capturing tasks.</div>';
    return;
  }

  // Sort by count
  const sorted = Object.entries(tagCounts).sort((a,b) => b[1]-a[1]);

  sorted.forEach(([tagName, count]) => {
    const tagDef = State.tags.find(t => t.name === tagName);
    const color = tagDef ? tagDef.color : '#888';
    const pct = Math.round((count/maxCount)*100);

    // Chart row
    const row = el('div'); row.className = 'tag-review-item';
    row.innerHTML = `
      <div class="tag-review-name">${escHtml(tagName)}</div>
      <div class="tag-review-track"><div class="tag-review-fill" style="width:${pct}%;background:${color}"></div></div>
      <div class="tag-review-count">${count}</div>`;
    chart.appendChild(row);

    // Breakdown row
    const done = tagDone[tagName] || 0;
    const donePct = Math.round((done/count)*100);
    const row2 = el('div'); row2.className = 'tag-review-item';
    row2.innerHTML = `
      <div class="tag-review-name" style="display:flex;align-items:center;gap:5px">
        <span style="width:8px;height:8px;border-radius:50%;background:${color};display:inline-block;flex-shrink:0"></span>
        ${escHtml(tagName)}
      </div>
      <div class="tag-review-track"><div class="tag-review-fill" style="width:${donePct}%;background:${color}88"></div></div>
      <div class="tag-review-count">${done}/${count}</div>`;
    breakdown.appendChild(row2);
  });
}

function setBar(id, val, total) {
  const pct = Math.round((val/total)*100);
  document.getElementById(id).style.width = pct + '%';
  document.getElementById(id+'-val').textContent = val;
}

function buildAgingList(cid, tasks, type) {
  const c = document.getElementById(cid);
  if (tasks.length === 0) { c.innerHTML = `<div class="empty-state"><strong>All clear</strong>No aging ${type} tasks.</div>`; return; }
  c.innerHTML = '';
  tasks.forEach(t => {
    const days = daysAgo(t.created_date);
    const hint = getHintForTask(t, State.hints);
    const item = el('div'); item.className = `aged-item ${type}`;
    const opts = type === 'signal'
      ? `<option>keep open</option><option>break into steps</option><option>delegate</option><option>ignore</option>`
      : `<option>carry over</option><option>delegate</option><option>ignore</option>`;
    item.innerHTML = `
      <div class="aged-name">${escHtml(t.task_name)}</div>
      <div class="aged-row">
        <div class="aged-tags"><span class="tag ${type==='signal'?'sig':'noi'}">${type}</span><span class="tag days">${days}d open</span></div>
        <select class="aged-select">${opts}</select>
      </div>
      ${hint ? `<div class="aged-hint">◎ ${escHtml(hint.message)}</div>` : ''}`;
    c.appendChild(item);
  });
}

function drawWeekChart(tasks) {
  const svg = document.getElementById('fr-chart');
  const daysContainer = document.getElementById('fr-chart-days');
  svg.innerHTML = ''; daysContainer.innerHTML = '';

  const now = new Date(); const dow = now.getDay();
  const sow = new Date(now); sow.setDate(now.getDate() - (dow === 0 ? 6 : dow - 1)); sow.setHours(0,0,0,0);

  // Work = Mon-Fri (5 days), Personal = Mon-Sun (7 days)
  const numDays = State.mode === 'personal' ? 7 : 5;
  const dayNames = ['mon','tue','wed','thu','fri','sat','sun'];

  const data = Array.from({length: numDays}, (_, i) => {
    const d = new Date(sow); d.setDate(sow.getDate() + i);
    const ds = d.toISOString().split('T')[0];
    // Count tasks COMPLETED on this day (by closed_date), not created
    const closed = tasks.filter(t => t.category === State.mode && t.closed_date === ds && t.status === 'done');
    return { sig: closed.filter(t => t.signal_or_noise==='signal').length, noi: closed.filter(t => t.signal_or_noise==='noise').length };
  });

  // Build day labels dynamically
  for (let i = 0; i < numDays; i++) {
    const span = document.createElement('span');
    span.className = 'chart-day';
    span.textContent = dayNames[i];
    daysContainer.appendChild(span);
  }

  // Adjust SVG viewBox for 7 days
  const W = numDays === 7 ? 440 : 320;
  svg.setAttribute('viewBox', `0 0 ${W} 70`);

  const maxVal = Math.max(...data.flatMap(d => [d.sig,d.noi]), 1);
  const H=70, bw= numDays === 7 ? 16 : 20, step=(W-20)/numDays;

  for (let y=0; y<=2; y++) {
    const ly = H-5-(y/2)*(H-15);
    const line = svgEl('line'); line.setAttribute('x1',0); line.setAttribute('x2',W); line.setAttribute('y1',ly); line.setAttribute('y2',ly);
    line.setAttribute('stroke', State.mode==='work' ? '#2e1a0e' : '#2a2a35'); line.setAttribute('stroke-width','0.5');
    svg.appendChild(line);
  }
  data.forEach((d,i) => {
    const cx = 22+i*step;
    const sigH = Math.max((d.sig/maxVal)*(H-15), d.sig>0?3:0);
    const noiH = Math.max((d.noi/maxVal)*(H-15), d.noi>0?3:0);
    const nb = svgEl('rect'); nb.setAttribute('x',cx-bw-2); nb.setAttribute('y',H-5-noiH); nb.setAttribute('width',bw); nb.setAttribute('height',noiH); nb.setAttribute('rx',2); nb.setAttribute('fill','rgba(245,158,11,.3)'); svg.appendChild(nb);
    const sb = svgEl('rect'); sb.setAttribute('x',cx+2); sb.setAttribute('y',H-5-sigH); sb.setAttribute('width',bw); sb.setAttribute('height',sigH); sb.setAttribute('rx',2); sb.setAttribute('fill','rgba(34,197,94,.4)'); svg.appendChild(sb);
  });
}

async function buildComparison(allTasks) {
  const grid = document.getElementById('compare-grid');
  const cat = allTasks.filter(t => t.category === State.mode);
  const now = new Date(); const dow = now.getDay();
  const sow = new Date(now); sow.setDate(now.getDate() - (dow===0?6:dow-1)); sow.setHours(0,0,0,0);
  const solw = new Date(sow); solw.setDate(sow.getDate()-7);
  const eolw = new Date(sow); eolw.setDate(sow.getDate()-1);
  const tw = cat.filter(t => t.created_date && new Date(t.created_date) >= sow);
  const lw = cat.filter(t => t.created_date && new Date(t.created_date) >= solw && new Date(t.created_date) <= eolw);
  function ws(tasks) {
    const sd = tasks.filter(t => t.signal_or_noise==='signal' && t.status==='done').length;
    const nd = tasks.filter(t => t.signal_or_noise==='noise' && t.status==='done').length;
    const closed = tasks.filter(t => ['done','delegated','ignored'].includes(t.status)).length;
    const ratio = nd===0 ? `${sd}:0` : (sd/Math.max(nd,1)).toFixed(1)+':1';
    const comp = tasks.length===0 ? '0%' : Math.round((closed/tasks.length)*100)+'%';
    return { sd, nd, ratio, comp, total: tasks.length };
  }
  const t = ws(tw), l = ws(lw);
  grid.innerHTML = `
    <div class="compare-table">
      <div class="compare-row header"><div class="compare-cell"></div><div class="compare-cell">this week</div><div class="compare-cell">last week</div></div>
      <div class="compare-row"><div class="compare-cell lbl">signals done</div><div class="compare-cell val ${t.sd>=l.sd?'up':'dn'}">${t.sd}</div><div class="compare-cell val">${l.sd}</div></div>
      <div class="compare-row"><div class="compare-cell lbl">noise done</div><div class="compare-cell val">${t.nd}</div><div class="compare-cell val">${l.nd}</div></div>
      <div class="compare-row"><div class="compare-cell lbl">ratio</div><div class="compare-cell val accent">${t.ratio}</div><div class="compare-cell val">${l.ratio}</div></div>
      <div class="compare-row"><div class="compare-cell lbl">completion</div><div class="compare-cell val">${t.comp}</div><div class="compare-cell val">${l.comp}</div></div>
      <div class="compare-row"><div class="compare-cell lbl">captured</div><div class="compare-cell val">${t.total}</div><div class="compare-cell val">${l.total}</div></div>
    </div>`;
}

async function closeWeek() {
  const btn = document.getElementById('fr-close-btn');
  btn.textContent = 'Saving…'; btn.disabled = true;
  try {
    await appendWeeklyReview(State.spreadsheetId, {
      week_number: getWeekNumber(), year: new Date().getFullYear(),
      signals_opened: 0, signals_closed: parseInt(document.getElementById('fr-sig-closed').textContent)||0,
      noise_accumulated: 0, noise_closed: parseInt(document.getElementById('fr-noi-closed').textContent)||0,
      dropped_count: parseInt(document.getElementById('fr-ignored').textContent)||0,
      delegated_count: parseInt(document.getElementById('fr-delegated').textContent)||0,
      completion_rate: document.getElementById('fr-completion').textContent,
      signal_noise_ratio: document.getElementById('fr-ratio-val').textContent,
      primary_focus: '', reflection_ratio: document.getElementById('ref-ratio')?.value||'',
      reflection_hardest: document.getElementById('ref-hard')?.value||'',
      reflection_next_focus: document.getElementById('ref-next')?.value||'',
    });
    btn.textContent = '✓ Week closed';
    setTimeout(() => { btn.textContent = 'Close week'; btn.disabled = false; showPane('capture'); }, 1500);
  } catch(err) { btn.textContent = 'Close week'; btn.disabled = false; alert(err.message); }
}

function computeStreak(tasks) {
  let streak = 0; const now = new Date();
  for (let i=0; i<30; i++) {
    const d = new Date(now); d.setDate(now.getDate()-i);
    const ds = d.toISOString().split('T')[0];
    if (tasks.some(t => t.closed_date===ds && t.status==='done')) streak++;
    else if (i>0) break;
  }
  return streak;
}

// ── SETTINGS ───────────────────────────────────────────
function initSettings() {
  document.getElementById('add-tag-btn').addEventListener('click', addNewTag);
  document.getElementById('new-tag-input').addEventListener('keydown', e => { if (e.key==='Enter') addNewTag(); });
  document.getElementById('save-tags-btn').addEventListener('click', saveTagsToSheet);
  document.getElementById('open-sheet-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: `https://docs.google.com/spreadsheets/d/${State.spreadsheetId}` });
  });
}

async function loadSettings() {
  await loadTagsFromSheet();
  renderTagManageList();
  renderColorPicker();
  const sheetEl = document.getElementById('sheet-id-display');
  if (sheetEl) sheetEl.textContent = State.spreadsheetId;
}

function renderTagManageList() {
  const list = document.getElementById('tag-manage-list');
  list.innerHTML = '';
  State.tags.forEach((tag, i) => {
    const item = el('div'); item.className = 'tag-manage-item';
    item.innerHTML = `
      <div class="tag-color-dot" style="background:${tag.color}" title="Color"></div>
      <input class="tag-manage-name" value="${escHtml(tag.name)}" placeholder="Tag name" data-idx="${i}">
      <button class="tag-delete-btn" data-idx="${i}">×</button>`;
    item.querySelector('.tag-manage-name').addEventListener('input', e => {
      State.tags[parseInt(e.target.dataset.idx)].name = e.target.value;
    });
    item.querySelector('.tag-delete-btn').addEventListener('click', e => {
      State.tags.splice(parseInt(e.target.dataset.idx), 1);
      renderTagManageList();
    });
    list.appendChild(item);
  });
}

function renderColorPicker() {
  const row = document.getElementById('color-picker-row');
  row.innerHTML = '<div style="font-size:10px;color:var(--w-muted);margin-bottom:4px;width:100%">Color for new tag:</div>';
  TAG_PALETTE.forEach(color => {
    const swatch = el('div'); swatch.className = 'color-swatch' + (color === State.newTagColor ? ' selected' : '');
    swatch.style.background = color;
    swatch.addEventListener('click', () => {
      State.newTagColor = color;
      renderColorPicker();
    });
    row.appendChild(swatch);
  });
}

function addNewTag() {
  const input = document.getElementById('new-tag-input');
  const name = input.value.trim();
  if (!name) return;
  if (State.tags.find(t => t.name.toLowerCase() === name.toLowerCase())) return;
  State.tags.push({ name, color: State.newTagColor });
  input.value = '';
  renderTagManageList();
  // Also refresh capture chips
  renderTagChips('cap-tags-wrap', State.selectedTagsForCapture, (tagName) => {
    const idx = State.selectedTagsForCapture.indexOf(tagName);
    if (idx >= 0) State.selectedTagsForCapture.splice(idx, 1);
    else State.selectedTagsForCapture.push(tagName);
  });
}

async function saveTagsToSheet() {
  const btn = document.getElementById('save-tags-btn');
  btn.textContent = 'Saving…'; btn.disabled = true;
  try {
    await writeTags(State.spreadsheetId, State.tags);
    btn.textContent = '✓ Saved';
    setTimeout(() => { btn.textContent = 'Save tags'; btn.disabled = false; }, 1500);
    // Refresh capture chips
    renderTagChips('cap-tags-wrap', State.selectedTagsForCapture, (tagName) => {
      const idx = State.selectedTagsForCapture.indexOf(tagName);
      if (idx >= 0) State.selectedTagsForCapture.splice(idx, 1);
      else State.selectedTagsForCapture.push(tagName);
    });
  } catch(err) {
    btn.textContent = 'Save tags'; btn.disabled = false;
    alert('Error: ' + err.message);
  }
}

async function signOut() {
  if (!confirm('This will sign out and clear all local data. Your Google Sheet will be kept.')) return;
  chrome.runtime.sendMessage({ type: 'REMOVE_AUTH_TOKEN' }, () => {
    chrome.storage.local.clear(() => { window.location.reload(); });
  });
}

// ── HELPERS ────────────────────────────────────────────
function el(tag) { return document.createElement(tag); }
function svgEl(tag) { return document.createElementNS('http://www.w3.org/2000/svg', tag); }
function escHtml(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// ══════════════════════════════════════
// OBSCURA INTERACTION LAYER
// ══════════════════════════════════════

// ── CONTEXTUAL NUDGES ─────────────────
const NUDGES = {
  work:     ["What is the primary objective?", "What moves the needle today?", "What must not slip through?", "One signal. What is it?"],
  personal: ["What deserves your full attention?", "What would make today meaningful?", "What are you avoiding?", "What needs to happen first?"]
};

function updateNudge() {
  const el = document.getElementById('capture-nudge');
  if (!el) return;
  const pool = NUDGES[State.mode] || NUDGES.work;
  const nudge = pool[Math.floor(Math.random() * pool.length)];
  el.textContent = nudge;
}

// ── MECHANICAL SWITCH FLASH ───────────
function triggerSNFlash(type) {
  const shell = document.getElementById('app-shell');
  shell.classList.remove('sn-flash-signal', 'sn-flash-noise');
  void shell.offsetWidth; // reflow
  shell.classList.add(type === 'signal' ? 'sn-flash-signal' : 'sn-flash-noise');
  setTimeout(() => shell.classList.remove('sn-flash-signal', 'sn-flash-noise'), 600);
}

// ── OSTRACIZE FILTER ──────────────────
let activeTagFilter = null;

function applyTagFilter(tagName) {
  const bar = document.getElementById('tag-filter-bar');
  const label = document.getElementById('tag-filter-label');

  if (activeTagFilter === tagName) {
    clearTagFilter(); return;
  }

  activeTagFilter = tagName;
  if (bar) { bar.classList.add('visible'); label.textContent = `· ${tagName}`; }

  document.querySelectorAll('.task-item').forEach(item => {
    const taskId = item.dataset.id;
    if (!taskId) return;
    const task = State.tasks.find(t => t.task_id === taskId);
    if (!task) return;
    const hasTag = task.tags && task.tags.includes(tagName);
    item.classList.toggle('is-ostracized', !hasTag);
  });
}

function clearTagFilter() {
  activeTagFilter = null;
  const bar = document.getElementById('tag-filter-bar');
  if (bar) bar.classList.remove('visible');
  document.querySelectorAll('.task-item').forEach(i => i.classList.remove('is-ostracized'));
}

// ── IMPLOSION ANIMATION ───────────────
async function implodeAndComplete(task, itemEl) {
  itemEl.classList.add('imploding');
  await new Promise(r => setTimeout(r, 380));
  task.status = 'done';
  const rowIdx = State.taskRowMap[task.task_id];
  if (rowIdx !== undefined) await updateTask(State.spreadsheetId, task, rowIdx);
  loadTasks();
}

// ── NOISE DECAY CHECK ─────────────────
const DECAY_WARNING = 7 * 24 * 60 * 60 * 1000;   // 7 days
const DECAY_BLOCK   = 10 * 24 * 60 * 60 * 1000;  // 10 days

function checkNoiseDecay(tasks) {
  const now = Date.now();
  const blockingTasks = tasks.filter(t => {
    if (t.signal_or_noise !== 'noise') return false;
    if (!['open','in_progress'].includes(t.status)) return false;
    const age = now - new Date(t.created_date).getTime();
    return age > DECAY_BLOCK;
  });
  if (blockingTasks.length > 0) showDecayModal(blockingTasks[0]);
}

function showDecayModal(task) {
  const existing = document.getElementById('decay-modal-overlay');
  if (existing) existing.remove();

  const overlay = el('div'); overlay.id = 'decay-modal-overlay'; overlay.className = 'decay-modal-overlay';
  overlay.innerHTML = `
    <div class="decay-modal">
      <div class="decay-modal-eyebrow">⚠ Noise Ledger — 10-Day Threshold</div>
      <div class="decay-modal-title">This task has lingered without resolution.</div>
      <div class="decay-modal-sub">Noise that persists without a decision consumes attention. Substantiate or archive it.</div>
      <div class="decay-modal-task">${escHtml(task.task_name)}</div>
      <div style="font-size:10px;font-family:var(--mono);color:var(--smoke-2)">${daysAgo(task.created_date)} days open</div>
      <textarea id="decay-reason" rows="3" placeholder="Why has this persisted? What does keeping it cost you?"></textarea>
      <div class="decay-modal-actions">
        <button class="decay-modal-archive" onclick="archiveDecayed('${task.task_id}')">Archive to Ledger</button>
        <button class="decay-modal-keep" onclick="keepDecayed('${task.task_id}')">Keep open</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
}

async function archiveDecayed(taskId) {
  const reason = document.getElementById('decay-reason')?.value.trim();
  if (!reason) { document.getElementById('decay-reason').style.borderColor = 'var(--danger)'; return; }
  const task = State.tasks.find(t => t.task_id === taskId);
  if (task) {
    task.status = 'ignored'; task.reason = reason;
    const rowIdx = State.taskRowMap[taskId];
    if (rowIdx !== undefined) await updateTask(State.spreadsheetId, task, rowIdx);
  }
  document.getElementById('decay-modal-overlay')?.remove();
  loadTasks();
}

function keepDecayed(taskId) {
  document.getElementById('decay-modal-overlay')?.remove();
  // Reset the clock by updating comment
  const task = State.tasks.find(t => t.task_id === taskId);
  if (task) {
    const reason = document.getElementById('decay-reason')?.value.trim();
    if (reason) { task.comment = (task.comment ? task.comment + '\n' : '') + `[kept ${new Date().toLocaleDateString()}]: ${reason}`; }
  }
}

// ── FOCUS SCORE ───────────────────────
function computeFocusScore(tasks) {
  const cat = tasks.filter(t => t.category === State.mode);
  const signalsDone = cat.filter(t => t.signal_or_noise === 'signal' && t.status === 'done').length;
  const totalIntentions = cat.filter(t => t.signal_or_noise === 'signal').length;
  if (totalIntentions === 0) return null;
  return Math.round((signalsDone / totalIntentions) * 100);
}

function renderFocusScore(tasks) {
  const el_num = document.getElementById('fr-focus-score');
  const el_sub = document.getElementById('fr-focus-score-sub');
  if (!el_num) return;

  // Week-scoped: same logic as loadReview
  const now = new Date(); const dow = now.getDay();
  const sow = new Date(now); sow.setDate(now.getDate() - (dow === 0 ? 6 : dow - 1)); sow.setHours(0,0,0,0);
  const sowStr = sow.toISOString().split('T')[0];
  const cat = tasks.filter(t => t.category === State.mode);
  const weekTasks = cat.filter(t => (t.created_date >= sowStr) || (t.closed_date && t.closed_date >= sowStr));
  const signals = weekTasks.filter(t => t.signal_or_noise === 'signal');
  const signalsDone = signals.filter(t => t.status === 'done').length;
  const totalIntentions = signals.length;

  if (totalIntentions === 0) { el_num.textContent = '—'; if (el_sub) el_sub.textContent = 'no signals this week'; return; }
  const score = Math.round((signalsDone / totalIntentions) * 100);
  el_num.textContent = score + '%';
  if (el_sub) el_sub.textContent = `${signalsDone} of ${totalIntentions} signals finished this week`;
}

// ── APPLY DECAY CLASSES TO TASK ITEMS ─
function applyDecayClasses() {
  const now = Date.now();
  document.querySelectorAll('.task-item.noise').forEach(item => {
    const taskId = item.dataset.id;
    const task = State.tasks.find(t => t.task_id === taskId);
    if (!task || !task.created_date) return;
    const age = now - new Date(task.created_date).getTime();
    item.classList.remove('noise-aged', 'noise-decayed');
    if (age > DECAY_BLOCK) item.classList.add('noise-decayed');
    else if (age > DECAY_WARNING) item.classList.add('noise-aged');
  });
}

// ── HOOK INTO EXISTING FUNCTIONS ──────
// Override applyMode to add nudge + atmospheric shift
const _origApplyMode = applyMode;
applyMode = function(mode) {
  _origApplyMode(mode);
  updateNudge();
};

// Hook SN toggle for flash
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.querySelectorAll('#cap-sn .sn-btn').forEach(btn => {
      btn.addEventListener('click', () => triggerSNFlash(btn.dataset.val));
    });
  }, 500);
});

// Override loadTasks to add decay + focus score
const _origRenderTaskList = renderTaskList;
renderTaskList = function() {
  _origRenderTaskList();
  setTimeout(() => {
    applyDecayClasses();
    if (activeTagFilter) applyTagFilter(activeTagFilter);
  }, 50);
};

// Override loadReview to add focus score
const _origLoadReview = loadReview;
loadReview = async function() {
  await _origLoadReview();
  renderFocusScore(State.tasks);
  checkNoiseDecay(State.tasks);
};

// Override loadTasks to check decay
const _origLoadTasks = loadTasks;
loadTasks = async function() {
  await _origLoadTasks();
  checkNoiseDecay(State.tasks);
};

// Make task tags clickable for ostracize
const _origBuildTaskItem = buildTaskItem;
buildTaskItem = function(task, isDone, idx, total) {
  const item = _origBuildTaskItem(task, isDone, idx, total);
  // Attach click to inline task-tag-chips after render
  setTimeout(() => {
    item.querySelectorAll('.task-tag-chip').forEach(chip => {
      chip.style.cursor = 'pointer';
      chip.title = 'Filter by this tag';
      chip.addEventListener('click', (e) => {
        e.stopPropagation();
        const tagName = chip.textContent.trim();
        applyTagFilter(tagName);
      });
    });
    // Override check button to use implosion
    const check = item.querySelector('.task-check');
    if (check && !isDone) {
      check.replaceWith(check.cloneNode(true));
      const newCheck = item.querySelector('.task-check');
      newCheck.addEventListener('click', e => { e.stopPropagation(); implodeAndComplete(task, item); });
    }
  }, 10);
  return item;
};

// Init nudge on load
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(updateNudge, 200);
});
