// sheets.js — Google Sheets API wrapper v3 (with tags)

const SHEETS_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';

const DEFAULT_TAGS = ['Health','Side-job','Learning','Family','Cases','Risk Assessment','Admin','Clara','Idea development'];

// ── AUTH ─────────────────────────────────────────────
async function getToken() {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'GET_AUTH_TOKEN' }, (res) => {
      if (!res) reject(new Error('No response from background'));
      else if (res.error) reject(new Error(res.error));
      else resolve(res.token);
    });
  });
}

async function apiFetch(url, options = {}, token) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `API error ${res.status}`);
  }
  return res.json();
}

// ── SETUP ────────────────────────────────────────────
async function createSpreadsheet() {
  const token = await getToken();

  const body = {
    properties: { title: 'Focus — Signal & Noise Tasks' },
    sheets: [
      { properties: { sheetId: 0, title: 'Tasks', index: 0 } },
      { properties: { sheetId: 1, title: 'Weekly Review', index: 1 } },
      { properties: { sheetId: 2, title: 'Tags', index: 2 } },
      { properties: { sheetId: 3, title: 'Dashboard', index: 3 } },
    ]
  };

  const spreadsheet = await apiFetch(SHEETS_BASE, { method: 'POST', body: JSON.stringify(body) }, token);
  const id = spreadsheet.spreadsheetId;

  // Tasks headers (now includes tags as column N)
  await apiFetch(`${SHEETS_BASE}/${id}/values/Tasks!A1:N1?valueInputOption=RAW`, {
    method: 'PUT',
    body: JSON.stringify({ values: [['task_id','task_name','category','signal_or_noise','status','due_date','comment','reason','source','created_date','week_number','days_open','closed_date','tags']] })
  }, token);

  // Weekly Review headers
  await apiFetch(`${SHEETS_BASE}/${id}/values/Weekly Review!A1:N1?valueInputOption=RAW`, {
    method: 'PUT',
    body: JSON.stringify({ values: [['week_number','year','signals_opened','signals_closed','noise_accumulated','noise_closed','dropped_count','delegated_count','completion_rate','signal_noise_ratio','primary_focus','reflection_ratio','reflection_hardest','reflection_next_focus']] })
  }, token);

  // Tags sheet — write default tags
  await apiFetch(`${SHEETS_BASE}/${id}/values/Tags!A1:B1?valueInputOption=RAW`, {
    method: 'PUT',
    body: JSON.stringify({ values: [['tag_name','color']] })
  }, token);

  const tagRows = DEFAULT_TAGS.map((t, i) => [t, TAG_COLORS[i % TAG_COLORS.length]]);
  await apiFetch(`${SHEETS_BASE}/${id}/values/Tags!A2:B?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, {
    method: 'POST',
    body: JSON.stringify({ values: tagRows })
  }, token);

  // Format headers
  const formatRequests = [0, 1, 2].map(sheetId => ({
    repeatCell: {
      range: { sheetId, startRowIndex: 0, endRowIndex: 1 },
      cell: { userEnteredFormat: { backgroundColor: { red: 1, green: 0.259, blue: 0.031 }, textFormat: { bold: true, foregroundColor: { red: 1, green: 1, blue: 1 } } } },
      fields: 'userEnteredFormat(backgroundColor,textFormat)'
    }
  }));
  await apiFetch(`${SHEETS_BASE}/${id}:batchUpdate`, { method: 'POST', body: JSON.stringify({ requests: formatRequests }) }, token);

  return id;
}

// ── TAGS ─────────────────────────────────────────────
const TAG_COLORS = ['#ff4208','#4827af','#22c55e','#f59e0b','#3b8bd4','#ef4444','#7e60dc','#ff693b','#0f6e56'];

async function readTags(spreadsheetId) {
  const token = await getToken();
  try {
    const res = await apiFetch(`${SHEETS_BASE}/${spreadsheetId}/values/Tags!A2:B`, {}, token);
    const rows = res.values || [];
    return rows.map((r, i) => ({ name: r[0] || '', color: r[1] || TAG_COLORS[i % TAG_COLORS.length] })).filter(t => t.name);
  } catch(_) {
    return DEFAULT_TAGS.map((name, i) => ({ name, color: TAG_COLORS[i % TAG_COLORS.length] }));
  }
}

async function writeTags(spreadsheetId, tags) {
  const token = await getToken();
  // Clear existing tag data rows
  await apiFetch(`${SHEETS_BASE}/${spreadsheetId}/values/Tags!A2:B?valueInputOption=RAW`, {
    method: 'PUT',
    body: JSON.stringify({ values: tags.map(t => [t.name, t.color]) })
  }, token);
}

// ── TASKS ─────────────────────────────────────────────
async function readAllTasks(spreadsheetId) {
  const token = await getToken();
  const res = await apiFetch(`${SHEETS_BASE}/${spreadsheetId}/values/Tasks!A2:N?majorDimension=ROWS`, {}, token);
  const rows = res.values || [];
  return rows.map(rowToTask);
}

function rowToTask(row) {
  return {
    task_id:         row[0]  || '',
    task_name:       row[1]  || '',
    category:        row[2]  || 'personal',
    signal_or_noise: row[3]  || 'signal',
    status:          row[4]  || 'open',
    due_date:        row[5]  || '',
    comment:         row[6]  || '',
    reason:          row[7]  || '',
    source:          row[8]  || 'manual',
    created_date:    row[9]  || '',
    week_number:     parseInt(row[10]) || 0,
    days_open:       parseInt(row[11]) || 0,
    closed_date:     row[12] || '',
    tags:            row[13] ? row[13].split(',').map(t => t.trim()).filter(Boolean) : [],
  };
}

function taskToRow(task) {
  return [
    task.task_id, task.task_name, task.category, task.signal_or_noise,
    task.status, task.due_date, task.comment, task.reason || '',
    task.source, task.created_date, task.week_number, task.days_open,
    task.closed_date, (task.tags || []).join(', ')
  ];
}

async function appendTask(spreadsheetId, task) {
  const token = await getToken();
  task.task_id      = generateId();
  task.created_date = today();
  task.week_number  = getWeekNumber();
  task.days_open    = 0;
  task.status       = task.status || 'open';
  task.source       = task.source || 'manual';
  task.closed_date  = '';
  task.tags         = task.tags || [];

  await apiFetch(
    `${SHEETS_BASE}/${spreadsheetId}/values/Tasks!A:N:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    { method: 'POST', body: JSON.stringify({ values: [taskToRow(task)] }) },
    token
  );
  return task;
}

async function updateTask(spreadsheetId, task, rowIndex) {
  const token = await getToken();
  const row = rowIndex + 2;
  const created = new Date(task.created_date);
  const now = new Date();
  task.days_open = Math.max(0, Math.floor((now - created) / (1000 * 60 * 60 * 24)));
  if (['done','delegated','ignored'].includes(task.status) && !task.closed_date) {
    task.closed_date = today();
  }
  task.tags = task.tags || [];
  await apiFetch(
    `${SHEETS_BASE}/${spreadsheetId}/values/Tasks!A${row}:N${row}?valueInputOption=RAW`,
    { method: 'PUT', body: JSON.stringify({ values: [taskToRow(task)] }) },
    token
  );
  return task;
}

// ── WEEKLY REVIEW ─────────────────────────────────────
async function appendWeeklyReview(spreadsheetId, review) {
  const token = await getToken();
  const row = [review.week_number, review.year, review.signals_opened, review.signals_closed, review.noise_accumulated, review.noise_closed, review.dropped_count, review.delegated_count, review.completion_rate, review.signal_noise_ratio, review.primary_focus, review.reflection_ratio, review.reflection_hardest, review.reflection_next_focus];
  await apiFetch(
    `${SHEETS_BASE}/${spreadsheetId}/values/Weekly Review!A:N:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    { method: 'POST', body: JSON.stringify({ values: [row] }) },
    token
  );
}

// ── HELPERS ───────────────────────────────────────────
function generateId() { return 'task_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7); }
function today() { return new Date().toISOString().split('T')[0]; }
function getWeekNumber() {
  const d = new Date(); d.setHours(0,0,0,0);
  d.setDate(d.getDate() + 4 - (d.getDay() || 7));
  const yearStart = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}
function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}
function daysAgo(dateStr) {
  if (!dateStr) return 0;
  return Math.max(0, Math.floor((new Date() - new Date(dateStr)) / (1000 * 60 * 60 * 24)));
}
function getHour() { return new Date().getHours(); }
function isMorning() { const h = getHour(); return h >= 5 && h < 16; }
