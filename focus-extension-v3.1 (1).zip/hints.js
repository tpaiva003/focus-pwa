// hints.js — Hint engine with locked thresholds

const THRESHOLDS = {
  SIGNAL_AGING_DAYS:      10,   // Signal open more than 10 days
  SIGNAL_NO_DEADLINE_DAYS: 5,   // Signal with no due date after 5 days
  NOISE_MAX_OPEN:         10,   // More than 10 noise tasks open simultaneously
  DELEGATED_FOLLOWUP_DAYS:15    // Delegated with no update after 15 days
};

function evaluateHints(tasks) {
  const hints = [];
  const openNoise = tasks.filter(t =>
    t.signal_or_noise === 'noise' &&
    (t.status === 'open' || t.status === 'in_progress')
  );

  // Noise accumulation (global)
  if (openNoise.length >= THRESHOLDS.NOISE_MAX_OPEN) {
    hints.push({
      type: 'noise_accumulation',
      global: true,
      message: `You have ${openNoise.length} noise tasks open. That's a lot of mental weight — time to clear some.`,
      severity: 'warning'
    });
  }

  tasks.forEach(task => {
    const days = daysAgo(task.created_date);
    const isOpen = task.status === 'open' || task.status === 'in_progress';

    if (!isOpen) return;

    // Signal aging
    if (task.signal_or_noise === 'signal' && days >= THRESHOLDS.SIGNAL_AGING_DAYS) {
      hints.push({
        type: 'signal_aging',
        task_id: task.task_id,
        message: `This signal has been open ${days} days — can we break it into steps?`,
        severity: 'info'
      });
    }

    // Signal no deadline
    if (
      task.signal_or_noise === 'signal' &&
      !task.due_date &&
      days >= THRESHOLDS.SIGNAL_NO_DEADLINE_DAYS
    ) {
      hints.push({
        type: 'signal_no_deadline',
        task_id: task.task_id,
        message: `This signal has no deadline — is that intentional?`,
        severity: 'info'
      });
    }

    // Noise aging (individual)
    if (task.signal_or_noise === 'noise' && days >= 14) {
      hints.push({
        type: 'noise_aging',
        task_id: task.task_id,
        message: `Open ${days} days — close it, delegate it, or consciously ignore it.`,
        severity: 'warning'
      });
    }

    // Delegated follow-up
    if (task.status === 'delegated' && days >= THRESHOLDS.DELEGATED_FOLLOWUP_DAYS) {
      hints.push({
        type: 'delegated_followup',
        task_id: task.task_id,
        message: `You delegated this ${days} days ago — any update?`,
        severity: 'info'
      });
    }
  });

  return hints;
}

function getHintForTask(task, allHints) {
  return allHints.find(h => h.task_id === task.task_id) || null;
}

function getGlobalHints(allHints) {
  return allHints.filter(h => h.global);
}
