// background.js — v2, robust token persistence

const CLIENT_ID = '1093598922846-a0aib49mg17nj8tp8n7asi8ph3vupbqi.apps.googleusercontent.com';
const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/drive.file'
].join(' ');

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_AUTH_TOKEN') {
    getToken()
      .then(token => sendResponse({ token }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }
  if (message.type === 'REMOVE_AUTH_TOKEN') {
    chrome.storage.local.remove(['oauth_token','oauth_token_expiry'], () => sendResponse({ success: true }));
    return true;
  }
  if (message.type === 'FORCE_REAUTH') {
    chrome.storage.local.remove(['oauth_token','oauth_token_expiry'], () => {
      getTokenViaFlow()
        .then(token => sendResponse({ token }))
        .catch(err => sendResponse({ error: err.message }));
    });
    return true;
  }
});

async function getToken() {
  // Check stored token first
  const stored = await new Promise(res => chrome.storage.local.get(['oauth_token','oauth_token_expiry'], res));
  if (stored.oauth_token && stored.oauth_token_expiry && stored.oauth_token_expiry > Date.now()) {
    return stored.oauth_token;
  }
  // Need fresh token
  return getTokenViaFlow();
}

async function getTokenViaFlow() {
  const redirectUri = `https://${chrome.runtime.id}.chromiumapp.org/`;
  const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  authUrl.searchParams.set('client_id', CLIENT_ID);
  authUrl.searchParams.set('response_type', 'token');
  authUrl.searchParams.set('redirect_uri', redirectUri);
  authUrl.searchParams.set('scope', SCOPES);
  authUrl.searchParams.set('prompt', 'select_account');

  const responseUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow(
      { url: authUrl.toString(), interactive: true },
      (url) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (!url) reject(new Error('Auth popup closed'));
        else resolve(url);
      }
    );
  });

  const hashParams = new URLSearchParams(new URL(responseUrl).hash.slice(1));
  const token = hashParams.get('access_token');
  const expiresIn = parseInt(hashParams.get('expires_in') || '3300');
  if (!token) throw new Error('No access token in OAuth response');

  // Store with expiry (shave 5 min off to be safe)
  await new Promise(res => chrome.storage.local.set({
    oauth_token: token,
    oauth_token_expiry: Date.now() + (expiresIn - 300) * 1000
  }, res));

  return token;
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'dailyCheck') chrome.storage.local.set({ hintsStale: true });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('dailyCheck', { periodInMinutes: 60 * 24 });
});
