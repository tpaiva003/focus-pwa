# Focus — Signal & Noise
## Browser Extension Setup Guide

---

### What this is
A Chrome/Edge browser extension that captures tasks, separates signal from noise, and builds a focus ritual — backed by Google Sheets.

---

### Before you install

You need a **Google Cloud OAuth 2.0 Client ID**. This is free and takes about 5 minutes.

#### Step 1 — Create a Google Cloud project

1. Go to https://console.cloud.google.com
2. Click **New Project**, name it "Focus Extension", click **Create**
3. In the left menu go to **APIs & Services → Library**
4. Search for **Google Sheets API** → click it → click **Enable**
5. Search for **Google Drive API** → click it → click **Enable**

#### Step 2 — Create OAuth credentials

1. Go to **APIs & Services → Credentials**
2. Click **Create Credentials → OAuth client ID**
3. If prompted, configure the **OAuth consent screen** first:
   - User Type: **External**
   - App name: **Focus Extension**
   - Support email: your Gmail
   - Save and continue (you can skip the rest)
4. Back in Credentials → Create Credentials → OAuth client ID:
   - Application type: **Chrome Extension**
   - Name: **Focus Extension**
   - Extension ID: (see Step 3 below to get this)

#### Step 3 — Get your Extension ID

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked** and select this folder
4. Copy the **Extension ID** shown under the extension name

#### Step 4 — Finish OAuth setup

1. Back in Google Cloud Console → Credentials → your OAuth client
2. Paste the Extension ID in the **Application ID** field
3. Click **Save**
4. Copy your **Client ID** (looks like `123456789-abc.apps.googleusercontent.com`)

#### Step 5 — Add Client ID to manifest

1. Open `manifest.json` in this folder
2. Replace `YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com` with your actual Client ID
3. Save the file

#### Step 6 — Reload the extension

1. Go back to `chrome://extensions`
2. Click the **refresh icon** on the Focus Extension card
3. Click the extension icon in your toolbar
4. The onboarding flow will start — click **Connect with Google**

---

### Edge (Microsoft) setup

The same extension works in Edge:

1. Open Edge and go to `edge://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked** and select this folder
4. The same Client ID works — Edge uses the Chrome extension API

---

### What gets created in your Google Drive

When you connect, the extension automatically creates a spreadsheet called:
**"Focus — Signal & Noise Tasks"**

It contains three tabs:
- **Tasks** — every task you capture
- **Weekly Review** — your Friday review records
- **Dashboard** — open in Google Sheets for charts

You can open this file anytime at sheets.google.com

---

### Hint engine thresholds

| Trigger | Threshold |
|---|---|
| Signal aging | Open more than 10 days |
| Signal no deadline | No due date after 5 days |
| Noise accumulation | More than 10 noise tasks open |
| Delegated follow-up | No update after 15 days |

---

### File structure

```
focus-extension/
├── manifest.json       — Extension config (add your Client ID here)
├── background.js       — Service worker, OAuth token management
├── popup.html          — All UI views
├── popup.css           — All styles
├── popup.js            — Application logic
├── sheets.js           — Google Sheets API wrapper
├── hints.js            — Hint engine with thresholds
└── README.md           — This file
```

---

### Troubleshooting

**"Error: No token received"**
→ Check that your Client ID is correct in manifest.json and that the Extension ID matches in Google Cloud Console.

**"API error 403"**
→ Make sure Google Sheets API and Google Drive API are both enabled in your Cloud project.

**"API error 404"**
→ Your spreadsheet ID may be stale. Clear extension storage: open DevTools on the popup (right-click → Inspect) and run `chrome.storage.local.clear()`, then reload.

**Popup is blank**
→ Open DevTools on the popup and check the Console for errors.

---

### Adding icons

Place PNG files in the `icons/` folder:
- `icon16.png` — 16×16px
- `icon48.png` — 48×48px  
- `icon128.png` — 128×128px

Until you add icons, the extension will show a default puzzle piece icon.
